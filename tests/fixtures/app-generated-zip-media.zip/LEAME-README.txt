Field Observer — export ZIP / ZIP export

RO: occurrence.csv are coloanele Darwin Core din butonul „⬇ Darwin Core”; în plus, associatedMedia conține căile relative ale fotografiilor și înregistrărilor audio din folderul media/ (separate prin " | "). scientificName este gol: aplicația nu captează specia.
ATENȚIE: acesta NU este o arhivă Darwin Core (nu are meta.xml) și nu a fost testat la GBIF. GBIF cere pentru multimedia adrese URL publice, nu fișiere din ZIP: încarcă fișierele pe un server al tău și înlocuiește căile cu URL-uri înainte de publicare.

EN: occurrence.csv has the Darwin Core columns of the "⬇ Darwin Core" button; in addition, associatedMedia holds the relative paths of the photos and audio recordings in the media/ folder (separated by " | "). scientificName is empty: the app does not capture the species.
NOTE: this is NOT a Darwin Core Archive (no meta.xml) and has not been tested with GBIF. GBIF expects public URLs for multimedia, not files inside a ZIP: upload the files to your own server and replace the paths with URLs before publishing.
